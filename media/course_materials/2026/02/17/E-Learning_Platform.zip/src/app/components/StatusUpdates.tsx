import { useState } from 'react';
import { Send, User, Heart, MessageCircle, Clock } from 'lucide-react';
import exampleImage from 'figma:asset/616a7ae2745da9b9ea06fd10c7196c9a1c0e5066.png';

interface StatusUpdate {
  id: string;
  author: string;
  authorAvatar?: string;
  message: string;
  timestamp: string;
  likes: number;
  comments: number;
  isOwn: boolean;
}

export function StatusUpdates() {
  const [newUpdate, setNewUpdate] = useState('');
  const [updates, setUpdates] = useState<StatusUpdate[]>([
    {
      id: '1',
      author: 'Emma Johnson',
      authorAvatar: exampleImage,
      message: 'Just finished the Web Development assignment! Really enjoying this course 🎉',
      timestamp: '5 min ago',
      likes: 12,
      comments: 3,
      isOwn: true,
    },
    {
      id: '2',
      author: 'John Smith',
      message: 'Looking for study partners for the upcoming Data Structures exam. Anyone interested?',
      timestamp: '30 min ago',
      likes: 8,
      comments: 5,
      isOwn: false,
    },
    {
      id: '3',
      author: 'Sarah Williams',
      message: 'Prof. Chen\'s lecture on algorithms was amazing today! Finally understand merge sort 💡',
      timestamp: '1 hour ago',
      likes: 15,
      comments: 2,
      isOwn: false,
    },
    {
      id: '4',
      author: 'Michael Brown',
      message: 'Completed all my assignments for the week. Time for a well-deserved break! ☕',
      timestamp: '2 hours ago',
      likes: 20,
      comments: 4,
      isOwn: false,
    },
  ]);

  const handlePostUpdate = () => {
    if (!newUpdate.trim()) return;

    const update: StatusUpdate = {
      id: Date.now().toString(),
      author: 'Emma Johnson',
      authorAvatar: exampleImage,
      message: newUpdate,
      timestamp: 'Just now',
      likes: 0,
      comments: 0,
      isOwn: true,
    };

    setUpdates([update, ...updates]);
    setNewUpdate('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handlePostUpdate();
    }
  };

  return (
    <div className="space-y-6">
      {/* Post Update Form */}
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <div className="flex gap-3">
          <img
            src={exampleImage}
            alt="Your avatar"
            className="w-10 h-10 rounded-full object-cover flex-shrink-0"
          />
          <div className="flex-1">
            <textarea
              value={newUpdate}
              onChange={(e) => setNewUpdate(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Share an update... (e.g., 'Finished with the assignment' or 'Really enjoying this course')"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={3}
            />
            <div className="flex justify-end mt-2">
              <button
                onClick={handlePostUpdate}
                disabled={!newUpdate.trim()}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                <Send className="w-4 h-4" />
                Post Update
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Updates Feed */}
      <div className="space-y-4">
        {updates.map((update) => (
          <div key={update.id} className="bg-white p-4 rounded-lg border border-gray-200">
            <div className="flex gap-3">
              {/* Avatar */}
              <div className="flex-shrink-0">
                {update.authorAvatar ? (
                  <img
                    src={update.authorAvatar}
                    alt={update.author}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-semibold text-gray-900">
                      {update.author}
                      {update.isOwn && (
                        <span className="ml-2 text-xs font-normal text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                          You
                        </span>
                      )}
                    </h4>
                    <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{update.timestamp}</span>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-gray-700 mb-3 leading-relaxed">{update.message}</p>

                {/* Actions */}
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <button className="flex items-center gap-1.5 hover:text-red-600 transition-colors">
                    <Heart className="w-4 h-4" />
                    <span>{update.likes}</span>
                  </button>
                  <button className="flex items-center gap-1.5 hover:text-blue-600 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span>{update.comments}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {updates.length === 0 && (
        <div className="text-center py-12 text-gray-500 bg-white rounded-lg border border-gray-200">
          <p className="text-lg font-medium mb-1">No updates yet</p>
          <p className="text-sm">Be the first to share an update!</p>
        </div>
      )}
    </div>
  );
}
