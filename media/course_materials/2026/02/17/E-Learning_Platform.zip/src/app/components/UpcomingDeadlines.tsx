import { Clock } from 'lucide-react';

type Deadline = {
  id: string;
  title: string;
  course: string;
  dueDate: string;
  dueTime: string;
  status: 'DUE' | 'OVERDUE' | 'UPCOMING';
};

export function UpcomingDeadlines() {
  const deadlines: Deadline[] = [
    {
      id: '1',
      title: 'Data Structures Fundamentals',
      course: 'Introduction to Computer Science',
      dueDate: 'Dec 10, 2025',
      dueTime: '11:59 PM',
      status: 'DUE',
    },
    {
      id: '2',
      title: 'Algorithm Practice Assignment',
      course: 'Data Structures & Algorithms',
      dueDate: 'Dec 14, 2025',
      dueTime: '10:24 PM',
      status: 'UPCOMING',
    },
    {
      id: '3',
      title: 'Database Design Quiz',
      course: 'Database Management Systems',
      dueDate: 'Dec 15, 2025',
      dueTime: '11:59 PM',
      status: 'UPCOMING',
    },
    {
      id: '4',
      title: 'Reading Assignment',
      course: 'Introduction to Computer Science',
      dueDate: 'Dec 20, 2025',
      dueTime: '12:30 AM',
      status: 'UPCOMING',
    },
  ];

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-5 h-5 text-gray-700" />
        <h2 className="text-lg font-semibold text-gray-900">Upcoming Deadlines</h2>
      </div>

      <div className="space-y-4">
        {deadlines.map((deadline, index) => (
          <div key={deadline.id}>
            <div className="py-2">
              <div className="flex items-start justify-between mb-1">
                <h3 className="font-medium text-sm text-gray-900">{deadline.title}</h3>
                <span
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    deadline.status === 'DUE'
                      ? 'bg-red-100 text-red-700'
                      : deadline.status === 'OVERDUE'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {deadline.status === 'DUE' ? 'Due' : 'Upcoming'}
                </span>
              </div>
              <p className="text-xs text-gray-600 mb-1">{deadline.course}</p>
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <Clock className="w-3 h-3" />
                <span>
                  {deadline.dueDate} | {deadline.dueTime}
                </span>
              </div>
            </div>
            {index < deadlines.length - 1 && (
              <div className="border-b border-dashed border-gray-300 mt-4"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}