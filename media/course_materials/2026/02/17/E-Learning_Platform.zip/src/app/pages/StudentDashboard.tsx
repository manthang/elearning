import { useState } from "react";
import {
  MessageCircle,
  LogOut,
  Search,
} from "lucide-react";
import { StudentProfile } from "../components/StudentProfile";
import { CoursesView } from "../components/CoursesView";
import { MessagesInbox } from "../components/MessagesInbox";
import { ChatModal } from "../components/ChatModal";
import { UpcomingDeadlines } from "../components/UpcomingDeadlines";
import { EditProfileModal } from "../components/EditProfileModal";
import { FeedbackModal } from "../components/FeedbackModal";
import { SearchPanel } from "../components/SearchPanel";
import { toast } from "sonner";
import { useAuth } from "@/app/contexts/AuthContext";

export function StudentDashboard() {
  const { user } = useAuth();
  const [isMessagingOpen, setIsMessagingOpen] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showSearchPanel, setShowSearchPanel] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [chatRecipient, setChatRecipient] = useState<any>(null);
  const [selectedCourseForFeedback, setSelectedCourseForFeedback] = useState<{
    id: string;
    title: string;
  } | null>(null);
  const [profileData, setProfileData] = useState({
    name: user?.name || "Emma Johnson",
    email: user?.email || "emma.johnson@edulearn.com",
    location: "New York, USA",
    joinDate: "September 2025",
    enrolledCourses: 4,
    bio: "Passionate about learning and technology",
    avatar: undefined as string | undefined,
  });

  const [unreadMessages, setUnreadMessages] = useState(3);

  // Mock course data for feedback
  const courses = {
    "1": "Introduction to Computer Science",
    "2": "Data Structures & Algorithms",
    "3": "Web Development Fundamentals",
    "4": "Database Management Systems",
  };

  const handleLeaveFeedback = (courseId: string) => {
    const courseTitle = courses[courseId as keyof typeof courses] || "Course";
    setSelectedCourseForFeedback({ id: courseId, title: courseTitle });
    setShowFeedbackModal(true);
  };

  const handleSubmitFeedback = (feedback: { rating: number; comment: string }) => {
    console.log("Feedback submitted:", {
      courseId: selectedCourseForFeedback?.id,
      ...feedback,
    });
    toast.success("Feedback submitted successfully!");
    // Here you would send the feedback to your backend
  };

  const handleStartCourse = (courseId: string) => {
    console.log("Start/Continue course:", courseId);
    // Navigate to course content
  };

  const handleEnroll = (courseId: string) => {
    console.log("Enroll in course:", courseId);
    toast.success("Successfully enrolled in course!");
    // Implement enrollment logic
  };

  const handleEditProfile = () => {
    setShowEditProfile(true);
  };

  const handleSaveProfile = (updatedProfile: {
    name: string;
    email: string;
    location: string;
    bio: string;
    avatar?: string;
  }) => {
    setProfileData({
      ...profileData,
      ...updatedProfile,
    });
    console.log("Profile updated:", updatedProfile);
    toast.success("Profile updated successfully!");
  };

  const handleLogout = () => {
    console.log("Logout");
    // Implement logout logic
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {user?.name || 'Student'}</h1>
            <p className="text-gray-600">Continue your learning journey today.</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMessagingOpen(true)}
              className="relative flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <MessageCircle className="w-5 h-5" />
              Messages
              {unreadMessages > 0 && (
                <span className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {unreadMessages}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowSearchPanel(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-400 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <Search className="w-5 h-5 text-gray-700" />
              Search Students/Teachers
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile and Deadlines */}
          <div className="lg:col-span-1 space-y-6">
            <StudentProfile
              onEditProfile={handleEditProfile}
              profileData={{
                name: profileData.name,
                location: profileData.location,
                joinDate: profileData.joinDate,
                enrolledCourses: profileData.enrolledCourses,
                bio: profileData.bio,
                avatar: profileData.avatar,
              }}
            />
            <UpcomingDeadlines />
          </div>

          {/* Right Column - Courses */}
          <div className="lg:col-span-2">
            <CoursesView
              onLeaveFeedback={handleLeaveFeedback}
              onStartCourse={handleStartCourse}
              onEnroll={handleEnroll}
            />
          </div>
        </div>
      </main>

      {/* Messaging Panel */}
      <MessagesInbox
        isOpen={isMessagingOpen}
        onClose={() => setIsMessagingOpen(false)}
        onOpenChat={(recipient) => {
          setChatRecipient(recipient);
          setShowChatModal(true);
        }}
      />

      {/* Chat Modal */}
      <ChatModal
        isOpen={showChatModal}
        onClose={() => setShowChatModal(false)}
        recipient={chatRecipient}
      />

      {/* Edit Profile Modal */}
      <EditProfileModal
        isOpen={showEditProfile}
        onClose={() => setShowEditProfile(false)}
        currentProfile={{
          name: profileData.name,
          email: profileData.email,
          location: profileData.location,
          bio: profileData.bio,
        }}
        onSave={handleSaveProfile}
      />

      {/* Feedback Modal */}
      {selectedCourseForFeedback && (
        <FeedbackModal
          isOpen={showFeedbackModal}
          onClose={() => setShowFeedbackModal(false)}
          courseTitle={selectedCourseForFeedback.title}
          onSubmit={handleSubmitFeedback}
        />
      )}

      {/* Search Panel */}
      <SearchPanel
        isOpen={showSearchPanel}
        onClose={() => setShowSearchPanel(false)}
      />
    </div>
  );
}