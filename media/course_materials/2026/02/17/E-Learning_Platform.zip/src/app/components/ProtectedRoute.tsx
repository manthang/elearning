import { Navigate } from 'react-router-dom';
import { useAuth } from '@/app/contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: 'student' | 'teacher';
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { user, isAuthenticated } = useAuth();

  // Not authenticated - redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Authenticated but wrong role - redirect to correct dashboard
  if (requiredRole && user?.role !== requiredRole) {
    return <Navigate to={user?.role === 'student' ? '/student' : '/teacher'} replace />;
  }

  // Authenticated and correct role
  return <>{children}</>;
}
