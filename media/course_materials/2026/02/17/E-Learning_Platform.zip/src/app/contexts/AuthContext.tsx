import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'teacher';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  signup: (email: string, password: string, name: string, role: 'student' | 'teacher') => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('edulearn_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const signup = (email: string, password: string, name: string, role: 'student' | 'teacher') => {
    // Get existing users or initialize empty array
    const users = JSON.parse(localStorage.getItem('edulearn_users') || '[]');
    
    // Check if user already exists
    if (users.find((u: any) => u.email === email)) {
      toast.error('An account with this email already exists');
      return;
    }

    // Create new user
    const newUser = {
      id: Date.now().toString(),
      email,
      password, // In production, this should be hashed!
      name,
      role,
    };

    // Save to users list
    users.push(newUser);
    localStorage.setItem('edulearn_users', JSON.stringify(users));
    
    toast.success('Account created successfully! Please log in.');
  };

  const login = (email: string, password: string): boolean => {
    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('edulearn_users') || '[]');
    
    // Demo accounts
    const demoAccounts = [
      { email: 'student@demo.com', password: 'password', name: 'Emma Johnson', role: 'student' as const, id: 'demo-student' },
      { email: 'teacher@demo.com', password: 'password', name: 'Prof. Tanya Udland', role: 'teacher' as const, id: 'demo-teacher' },
    ];

    // Check demo accounts first
    const demoUser = demoAccounts.find(u => u.email === email && u.password === password);
    if (demoUser) {
      const { password: _, ...userWithoutPassword } = demoUser;
      setUser(userWithoutPassword);
      localStorage.setItem('edulearn_user', JSON.stringify(userWithoutPassword));
      toast.success(`Welcome back, ${demoUser.name}!`);
      
      // Navigate based on role
      navigate(demoUser.role === 'student' ? '/student' : '/teacher');
      return true;
    }

    // Check registered users
    const foundUser = users.find((u: any) => u.email === email && u.password === password);
    
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('edulearn_user', JSON.stringify(userWithoutPassword));
      toast.success(`Welcome back, ${foundUser.name}!`);
      
      // Navigate based on role
      navigate(foundUser.role === 'student' ? '/student' : '/teacher');
      return true;
    }

    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('edulearn_user');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
