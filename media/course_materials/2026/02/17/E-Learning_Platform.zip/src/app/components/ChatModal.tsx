import { useState, useRef, useEffect } from "react";
import { X, Send, Paperclip, Smile, Image as ImageIcon, User, ArrowLeft } from "lucide-react";

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBack?: () => void;
  recipient: {
    id: string;
    name: string;
    type: "student" | "teacher";
  } | null;
}

interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: Date;
  isOwn: boolean;
}

export function ChatModal({ isOpen, onClose, onBack, recipient }: ChatModalProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      senderId: recipient?.id || "",
      text: "Hello! How can I help you?",
      timestamp: new Date(Date.now() - 3600000),
      isOwn: false,
    },
    {
      id: "2",
      senderId: "me",
      text: "Hi! I have a question about the assignment.",
      timestamp: new Date(Date.now() - 3000000),
      isOwn: true,
    },
    {
      id: "3",
      senderId: recipient?.id || "",
      text: "Sure! What would you like to know?",
      timestamp: new Date(Date.now() - 2400000),
      isOwn: false,
    },
  ]);
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: "me",
      text: messageText,
      timestamp: new Date(),
      isOwn: true,
    };

    setMessages([...messages, newMessage]);
    setMessageText("");

    // Simulate response after 1 second
    setTimeout(() => {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        senderId: recipient?.id || "",
        text: "Thanks for your message! I'll get back to you shortly.",
        timestamp: new Date(),
        isOwn: false,
      };
      setMessages((prev) => [...prev, response]);
    }, 1000);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-3xl h-[600px] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                onClick={onBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Back to messages"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </button>
            )}
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                recipient?.type === "student" ? "bg-blue-100" : "bg-green-100"
              }`}
            >
              <User
                className={`w-5 h-5 ${
                  recipient?.type === "student" ? "text-blue-600" : "text-green-600"
                }`}
              />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">{recipient?.name}</h2>
              <p className="text-xs text-gray-500">
                {recipient?.type === "student" ? "Student" : "Teacher"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[70%] ${
                  message.isOwn
                    ? "bg-blue-600 text-white rounded-2xl rounded-br-sm"
                    : "bg-white text-gray-900 rounded-2xl rounded-bl-sm border border-gray-200"
                } px-4 py-3`}
              >
                <p className="text-sm leading-relaxed">{message.text}</p>
                <p
                  className={`text-xs mt-1 ${
                    message.isOwn ? "text-blue-100" : "text-gray-500"
                  }`}
                >
                  {formatTime(message.timestamp)}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-200 bg-white">
          <form onSubmit={handleSendMessage} className="flex items-end gap-3">
            {/* Attachment buttons */}
            <div className="flex gap-2">
              <button
                type="button"
                className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                title="Attach file"
              >
                <Paperclip className="w-5 h-5" />
              </button>
              <button
                type="button"
                className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                title="Add image"
              >
                <ImageIcon className="w-5 h-5" />
              </button>
              <button
                type="button"
                className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                title="Add emoji"
              >
                <Smile className="w-5 h-5" />
              </button>
            </div>

            {/* Text input */}
            <div className="flex-1">
              <textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Type your message..."
                rows={1}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (messageText.trim()) {
                      // Create new message directly here to avoid double submission
                      const newMessage: Message = {
                        id: Date.now().toString(),
                        senderId: "me",
                        text: messageText,
                        timestamp: new Date(),
                        isOwn: true,
                      };

                      setMessages((prev) => [...prev, newMessage]);
                      setMessageText("");

                      // Simulate response after 1 second
                      setTimeout(() => {
                        const response: Message = {
                          id: (Date.now() + 1).toString(),
                          senderId: recipient?.id || "",
                          text: "Thanks for your message! I'll get back to you shortly.",
                          timestamp: new Date(),
                          isOwn: false,
                        };
                        setMessages((prev) => [...prev, response]);
                      }, 1000);
                    }
                  }
                }}
              />
            </div>

            {/* Send button */}
            <button
              type="submit"
              disabled={!messageText.trim()}
              className="p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed self-end mb-0"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
          <p className="text-xs text-gray-500 mt-2">Press Enter to send, Shift + Enter for new line</p>
        </div>
      </div>
    </div>
  );
}