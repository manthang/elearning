import { GraduationCap, LogOut } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { NotificationDropdown } from "./NotificationDropdown";
import { useAuth } from "@/app/contexts/AuthContext";

export function Header() {
  const location = useLocation();
  const { logout } = useAuth();
  const isStudentRoute = location.pathname.startsWith("/student");
  const isTeacherRoute = location.pathname.startsWith("/teacher");

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">EduLearn</h1>
          </div>
          <nav className="flex items-center gap-6">
            {isTeacherRoute && <NotificationDropdown />}
            {isStudentRoute && <NotificationDropdown />}
            <button 
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-red-600 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}