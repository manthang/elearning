import { useState } from "react";
import { X, Users, FileText, Upload, Trash2, Download, File } from "lucide-react";
import { toast } from "sonner";

interface CourseManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  course: {
    id: string;
    name: string;
    students: Array<{ id: string; name: string; email: string; enrolledDate: string }>;
  };
}

export function CourseManagementModal({ isOpen, onClose, course }: CourseManagementModalProps) {
  const [activeTab, setActiveTab] = useState<"students" | "files">("students");
  const [students, setStudents] = useState(course.students);
  const [files, setFiles] = useState([
    { id: "1", name: "Lecture 1 - Introduction.pdf", size: "2.4 MB", uploadedDate: "Jan 10, 2026" },
    { id: "2", name: "Assignment 1.docx", size: "156 KB", uploadedDate: "Jan 12, 2026" },
    { id: "3", name: "Course Syllabus.pdf", size: "890 KB", uploadedDate: "Jan 8, 2026" },
  ]);

  const handleRemoveStudent = (studentId: string) => {
    const student = students.find((s) => s.id === studentId);
    if (student) {
      setStudents((prev) => prev.filter((s) => s.id !== studentId));
      toast.success(`${student.name} removed from course`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = e.target.files;
    if (uploadedFiles && uploadedFiles.length > 0) {
      const newFiles = Array.from(uploadedFiles).map((file, index) => ({
        id: `new-${Date.now()}-${index}`,
        name: file.name,
        size: `${(file.size / 1024).toFixed(0)} KB`,
        uploadedDate: new Date().toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
        }),
      }));
      setFiles((prev) => [...newFiles, ...prev]);
      toast.success(`${uploadedFiles.length} file(s) uploaded successfully`);
    }
  };

  const handleDeleteFile = (fileId: string) => {
    const file = files.find((f) => f.id === fileId);
    if (file) {
      setFiles((prev) => prev.filter((f) => f.id !== fileId));
      toast.success(`${file.name} deleted`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">{course.name}</h2>
            <p className="text-sm text-gray-600 mt-1">Manage students and course materials</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 px-6">
          <div className="flex gap-8">
            <button
              onClick={() => setActiveTab("students")}
              className={`py-3 border-b-2 transition-colors font-medium ${
                activeTab === "students"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              <Users className="w-4 h-4 inline mr-2" />
              Students ({students.length})
            </button>
            <button
              onClick={() => setActiveTab("files")}
              className={`py-3 border-b-2 transition-colors font-medium ${
                activeTab === "files"
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              <FileText className="w-4 h-4 inline mr-2" />
              Course Materials ({files.length})
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === "students" ? (
            <div className="space-y-3">
              {students.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No students enrolled yet</p>
                </div>
              ) : (
                students.map((student) => (
                  <div
                    key={student.id}
                    className="border border-gray-200 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{student.name}</h3>
                        <p className="text-sm text-gray-600">{student.email}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          Enrolled: {student.enrolledDate}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRemoveStudent(student.id)}
                      className="px-4 py-2 text-sm text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors font-medium flex items-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      Remove
                    </button>
                  </div>
                ))
              )}
            </div>
          ) : (
            <div>
              {/* Upload Area */}
              <div className="mb-6">
                <label className="block w-full border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 hover:bg-blue-50 transition-colors cursor-pointer">
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-sm font-medium text-gray-900 mb-1">
                    Click to upload files
                  </p>
                  <p className="text-xs text-gray-500">
                    PDF, DOC, PPT, or any other teaching materials
                  </p>
                </label>
              </div>

              {/* Files List */}
              <div className="space-y-3">
                {files.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No files uploaded yet</p>
                  </div>
                ) : (
                  files.map((file) => (
                    <div
                      key={file.id}
                      className="border border-gray-200 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <File className="w-5 h-5 text-purple-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-900 truncate">{file.name}</h3>
                          <p className="text-sm text-gray-600">
                            {file.size} • Uploaded {file.uploadedDate}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title="Download"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteFile(file.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}