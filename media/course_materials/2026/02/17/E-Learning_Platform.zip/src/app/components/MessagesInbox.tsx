import { useState } from "react";
import { X, Search, User, Circle } from "lucide-react";
import { useLocation } from "react-router-dom";

interface Conversation {
  id: string;
  name: string;
  type: "student" | "teacher";
  lastMessage: string;
  timestamp: string;
  unread: boolean;
  unreadCount?: number;
}

interface MessagesInboxProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectConversation?: (conversation: Conversation) => void;
  onMarkAsRead?: (conversationId: string) => void;
  onOpenChat?: (recipient: { id: string; name: string; type: "student" | "teacher" }) => void;
}

export function MessagesInbox({
  isOpen,
  onClose,
  onSelectConversation,
  onMarkAsRead,
  onOpenChat,
}: MessagesInboxProps) {
  const location = useLocation();
  const isStudentRoute = location.pathname.startsWith("/student");
  
  const [searchQuery, setSearchQuery] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>(
    isStudentRoute
      ? [
          {
            id: "1",
            name: "Prof. Tanya Udland",
            type: "teacher",
            lastMessage: "Great work on your latest assignment!",
            timestamp: "10 min ago",
            unread: true,
            unreadCount: 2,
          },
          {
            id: "2",
            name: "Prof. Michael Chen",
            type: "teacher",
            lastMessage: "Office hours tomorrow at 2pm.",
            timestamp: "1 hour ago",
            unread: true,
            unreadCount: 1,
          },
          {
            id: "3",
            name: "John Smith",
            type: "student",
            lastMessage: "Hey! Want to study together for the exam?",
            timestamp: "3 hours ago",
            unread: false,
          },
          {
            id: "4",
            name: "Sarah Williams",
            type: "student",
            lastMessage: "Did you understand the last lecture?",
            timestamp: "Yesterday",
            unread: false,
          },
          {
            id: "5",
            name: "Prof. Lisa Anderson",
            type: "teacher",
            lastMessage: "Remember to submit your project by Friday.",
            timestamp: "2 days ago",
            unread: false,
          },
        ]
      : [
          {
            id: "1",
            name: "Emma Johnson",
            type: "student",
            lastMessage: "Hi Professor! I have a question about the assignment...",
            timestamp: "2 min ago",
            unread: true,
            unreadCount: 2,
          },
          {
            id: "2",
            name: "Michael Chen",
            type: "student",
            lastMessage: "Thank you for the feedback on my project!",
            timestamp: "1 hour ago",
            unread: true,
            unreadCount: 1,
          },
          {
            id: "3",
            name: "Prof. Robert Smith",
            type: "teacher",
            lastMessage: "Let's discuss the curriculum changes next week.",
            timestamp: "3 hours ago",
            unread: false,
          },
          {
            id: "4",
            name: "Sarah Williams",
            type: "student",
            lastMessage: "Could you please review my submitted work?",
            timestamp: "Yesterday",
            unread: false,
          },
          {
            id: "5",
            name: "David Martinez",
            type: "student",
            lastMessage: "I'll submit the assignment by tomorrow.",
            timestamp: "2 days ago",
            unread: false,
          },
        ]
  );

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleConversationClick = (conversation: Conversation) => {
    if (conversation.unread) {
      onMarkAsRead?.(conversation.id);
      setConversations((prev) =>
        prev.map((c) =>
          c.id === conversation.id ? { ...c, unread: false, unreadCount: 0 } : c
        )
      );
    }
    
    // Support both callback styles
    if (onSelectConversation) {
      onSelectConversation(conversation);
    }
    
    if (onOpenChat) {
      onOpenChat({ id: conversation.id, name: conversation.name, type: conversation.type });
      onClose(); // Close the inbox when opening chat
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl h-[700px] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Messages</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <p className="text-lg">No conversations found</p>
              <p className="text-sm mt-2">Start a conversation by searching for students or teachers</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredConversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => handleConversationClick(conversation)}
                  className={`w-full px-6 py-4 flex items-start gap-4 hover:bg-gray-50 transition-colors text-left ${
                    conversation.unread ? "bg-blue-50/50" : ""
                  }`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                      conversation.type === "student"
                        ? "bg-blue-100"
                        : "bg-green-100"
                    }`}
                  >
                    <User
                      className={`w-6 h-6 ${
                        conversation.type === "student"
                          ? "text-blue-600"
                          : "text-green-600"
                      }`}
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <h3
                          className={`font-semibold ${
                            conversation.unread
                              ? "text-gray-900"
                              : "text-gray-700"
                          }`}
                        >
                          {conversation.name}
                        </h3>
                        {conversation.unread && (
                          <Circle className="w-2 h-2 fill-blue-600 text-blue-600" />
                        )}
                      </div>
                      <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                        {conversation.timestamp}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p
                        className={`text-sm truncate ${
                          conversation.unread
                            ? "text-gray-900 font-medium"
                            : "text-gray-600"
                        }`}
                      >
                        {conversation.lastMessage}
                      </p>
                      {conversation.unreadCount && conversation.unreadCount > 0 && (
                        <span className="ml-2 px-2 py-0.5 bg-blue-600 text-white text-xs font-bold rounded-full flex-shrink-0">
                          {conversation.unreadCount}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {conversation.type === "student" ? "Student" : "Teacher"}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}