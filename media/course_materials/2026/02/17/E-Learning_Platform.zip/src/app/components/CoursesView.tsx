import { useState } from 'react';
import { Search, BookmarkPlus, Play, MessageSquare } from 'lucide-react';
import { CourseCard } from './CourseCard';
import { StatusUpdates } from './StatusUpdates';

export type Course = {
  id: string;
  title: string;
  instructor: string;
  progress: number;
  status: 'ACTIVE' | 'INACTIVE';
  isEnrolled?: boolean;
};

interface CoursesViewProps {
  onLeaveFeedback: (courseId: string) => void;
  onStartCourse: (courseId: string) => void;
  onEnroll: (courseId: string) => void;
}

export function CoursesView({ onLeaveFeedback, onStartCourse, onEnroll }: CoursesViewProps) {
  const [activeTab, setActiveTab] = useState<'my-courses' | 'all-courses' | 'status-updates'>('my-courses');
  const [searchQuery, setSearchQuery] = useState('');
  const [enrolledCourseIds, setEnrolledCourseIds] = useState<string[]>(['1', '2', '3', '4']);

  const allCoursesData: Course[] = [
    {
      id: '1',
      title: 'Introduction to Computer Science',
      instructor: 'Prof. Tanya Udland',
      progress: 75,
      status: 'ACTIVE',
      isEnrolled: true,
    },
    {
      id: '2',
      title: 'Data Structures & Algorithms',
      instructor: 'Prof. Michael Chen',
      progress: 60,
      status: 'ACTIVE',
      isEnrolled: true,
    },
    {
      id: '3',
      title: 'Web Development Fundamentals',
      instructor: 'Prof. Lisa Anderson',
      progress: 85,
      status: 'ACTIVE',
      isEnrolled: true,
    },
    {
      id: '4',
      title: 'Database Management Systems',
      instructor: 'Prof. David Wilson',
      progress: 40,
      status: 'ACTIVE',
      isEnrolled: true,
    },
    {
      id: '5',
      title: 'Machine Learning Basics',
      instructor: 'Prof. Sarah Miller',
      progress: 0,
      status: 'INACTIVE',
      isEnrolled: false,
    },
    {
      id: '6',
      title: 'Mobile App Development',
      instructor: 'Prof. John Smith',
      progress: 0,
      status: 'INACTIVE',
      isEnrolled: false,
    },
    {
      id: '7',
      title: 'Cloud Computing Essentials',
      instructor: 'Prof. Emily Brown',
      progress: 0,
      status: 'INACTIVE',
      isEnrolled: false,
    },
  ];

  const handleEnroll = (courseId: string) => {
    setEnrolledCourseIds([...enrolledCourseIds, courseId]);
    onEnroll(courseId);
  };

  // Update course enrollment status based on state
  const coursesWithEnrollment = allCoursesData.map(course => ({
    ...course,
    isEnrolled: enrolledCourseIds.includes(course.id),
    status: enrolledCourseIds.includes(course.id) ? 'ACTIVE' : 'INACTIVE',
  })) as Course[];

  const myCourses = coursesWithEnrollment.filter(course => course.isEnrolled);
  const allCourses = coursesWithEnrollment;

  const displayedCourses = activeTab === 'my-courses' ? myCourses : allCourses;
  const filteredCourses = displayedCourses.filter(
    (course) =>
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200">
      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('my-courses')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'my-courses'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          My Courses
        </button>
        <button
          onClick={() => setActiveTab('all-courses')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'all-courses'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          All Courses
        </button>
        <button
          onClick={() => setActiveTab('status-updates')}
          className={`px-4 py-2 font-medium text-sm transition-colors relative ${
            activeTab === 'status-updates'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Status Updates
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'status-updates' ? (
        <StatusUpdates />
      ) : (
        <>
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search course names"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Courses Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onLeaveFeedback={onLeaveFeedback}
                onStartCourse={onStartCourse}
                onEnroll={handleEnroll}
              />
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No courses found matching your search.
            </div>
          )}
        </>
      )}
    </div>
  );
}