import { MapPin, Calendar, Award, Edit2 } from 'lucide-react';
import exampleImage from 'figma:asset/616a7ae2745da9b9ea06fd10c7196c9a1c0e5066.png';

interface StudentProfileProps {
  onEditProfile: () => void;
  profileData: {
    name: string;
    location: string;
    joinDate: string;
    enrolledCourses: number;
    bio: string;
    avatar?: string;
  };
}

export function StudentProfile({ onEditProfile, profileData }: StudentProfileProps) {
  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <div className="relative">
            {profileData.avatar ? (
              <img
                src={profileData.avatar}
                alt={profileData.name}
                className="w-16 h-16 rounded-full object-cover"
              />
            ) : (
              <img
                src={exampleImage}
                alt={profileData.name}
                className="w-16 h-16 rounded-full object-cover"
              />
            )}
            <div
              className="absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white bg-green-500"
              title="Online"
            />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">{profileData.name}</h2>
            <p className="text-sm text-gray-600 mb-1">Student</p>
            {profileData.bio && (
              <p className="text-xs text-gray-500 italic mb-2 max-w-[200px]">
                "{profileData.bio}"
              </p>
            )}
            <div className="flex flex-col gap-1.5 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>{profileData.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Joined {profileData.joinDate}</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4" />
                <span>{profileData.enrolledCourses} Enrolled Courses</span>
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={onEditProfile}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Edit2 className="w-4 h-4" />
          Edit
        </button>
      </div>
    </div>
  );
}