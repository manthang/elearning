import { useState } from "react";
import { GraduationCap, BookOpen, Users, Calendar, Award, TrendingUp, Search, MessageCircle, Edit } from "lucide-react";
import { SearchPanel } from "../components/SearchPanel";
import { AddCourseModal } from "../components/AddCourseModal";
import { EditCourseModal } from "../components/EditCourseModal";
import { CourseManagementModal } from "../components/CourseManagementModal";
import { MessagesInbox } from "../components/MessagesInbox";
import { ChatModal } from "../components/ChatModal";
import { toast } from "sonner";
import { useAuth } from "@/app/contexts/AuthContext";

export function TeacherDashboard() {
  const { user } = useAuth();
  const [showSearchPanel, setShowSearchPanel] = useState(false);
  const [showAddCourseModal, setShowAddCourseModal] = useState(false);
  const [showEditCourseModal, setShowEditCourseModal] = useState(false);
  const [showCourseManagement, setShowCourseManagement] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [showMessagesInbox, setShowMessagesInbox] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(3);
  const [showChatModal, setShowChatModal] = useState(false);
  const [chatRecipient, setChatRecipient] = useState<any>(null);

  // Simulate incoming message notification (in production, this would be triggered by WebSocket or polling)
  const simulateIncomingMessage = () => {
    toast(
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
          <MessageCircle className="w-5 h-5 text-blue-600" />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-gray-900">New message from Emma Johnson</p>
          <p className="text-sm text-gray-600">Hi Professor! I have a question...</p>
        </div>
      </div>,
      {
        duration: 5000,
        action: {
          label: "View",
          onClick: () => setShowMessagesInbox(true),
        },
      }
    );
    setUnreadMessages((prev) => prev + 1);
  };

  const stats = [
    { label: "Total Students", value: "156", icon: Users, color: "text-blue-600" },
    { label: "Active Courses", value: "8", icon: BookOpen, color: "text-green-600" },
    { label: "Assignments", value: "24", icon: Calendar, color: "text-orange-600" },
  ];

  const [courses, setCourses] = useState([
    {
      id: "1",
      name: "Introduction to Computer Science",
      students: [
        { id: "1", name: "Emma Johnson", email: "emma.j@edu.com", enrolledDate: "Jan 5, 2026" },
        { id: "2", name: "Michael Chen", email: "m.chen@edu.com", enrolledDate: "Jan 6, 2026" },
      ],
      pending: 8,
    },
    {
      id: "2",
      name: "Data Structures & Algorithms",
      students: [
        { id: "3", name: "Sarah Williams", email: "s.williams@edu.com", enrolledDate: "Jan 7, 2026" },
      ],
      pending: 5,
    },
    {
      id: "3",
      name: "Web Development Fundamentals",
      students: [
        { id: "4", name: "David Martinez", email: "d.martinez@edu.com", enrolledDate: "Jan 8, 2026" },
      ],
      pending: 12,
    },
    {
      id: "4",
      name: "Database Management Systems",
      students: [],
      pending: 3,
    },
  ]);

  const handleAddCourse = (courseData: any) => {
    const newCourse = {
      id: `${courses.length + 1}`,
      name: courseData.title,
      students: [],
      pending: 0,
    };
    setCourses([newCourse, ...courses]);
    toast.success("Course created successfully!");
  };

  const handleEditCourse = (course: any) => {
    setSelectedCourse(course);
    setShowEditCourseModal(true);
  };

  const handleUpdateCourse = (courseId: string, courseData: any) => {
    setCourses(courses.map(course => 
      course.id === courseId 
        ? { ...course, name: courseData.title } 
        : course
    ));
  };

  const handleManageCourse = (course: any) => {
    setSelectedCourse(course);
    setShowCourseManagement(true);
  };

  const handleSelectConversation = (conversation: any) => {
    setChatRecipient({
      id: conversation.id,
      name: conversation.name,
      type: conversation.type,
    });
    setShowMessagesInbox(false);
    setShowChatModal(true);
  };

  const handleBackToInbox = () => {
    setShowChatModal(false);
    setChatRecipient(null);
    setShowMessagesInbox(true);
  };

  const handleMarkAsRead = (conversationId: string) => {
    setUnreadMessages((prev) => Math.max(0, prev - 1));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {user?.name || 'Professor'}</h1>
            <p className="text-gray-600">Here's what's happening with your courses today.</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowMessagesInbox(true)}
              className="relative flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <MessageCircle className="w-5 h-5" />
              Messages
              {unreadMessages > 0 && (
                <span className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {unreadMessages}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowSearchPanel(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-400 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              <Search className="w-5 h-5 text-gray-700" />
              Search Students/Teachers
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                <span className="text-2xl font-bold text-gray-900">{stat.value}</span>
              </div>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* My Courses */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">My Courses</h2>
                <button
                  onClick={() => setShowAddCourseModal(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Create New Course
                </button>
              </div>

              <div className="space-y-4">
                {courses.map((course) => (
                  <div key={course.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-semibold text-gray-900">{course.name}</h3>
                          <button
                            onClick={() => handleEditCourse(course)}
                            className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors"
                            aria-label="Edit course"
                          >
                            <Edit className="w-5 h-5 text-gray-600" />
                          </button>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {course.students.length} students
                          </span>
                          <span className="flex items-center gap-1 text-orange-600 font-medium">
                            <Calendar className="w-4 h-4" />
                            {course.pending} pending reviews
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                        View Course
                      </button>
                      <button
                        onClick={() => handleManageCourse(course)}
                        className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
                      >
                        Manage
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions & Upcoming */}
          <div className="lg:col-span-1 space-y-6">
            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button className="w-full flex items-center gap-3 px-4 py-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium">
                  <BookOpen className="w-5 h-5" />
                  Grade Assignments
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors text-sm font-medium">
                  <Award className="w-5 h-5" />
                  Post Announcement
                </button>
                <button className="w-full flex items-center gap-3 px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors text-sm font-medium">
                  <Users className="w-5 h-5" />
                  View Students
                </button>
                <button 
                  onClick={simulateIncomingMessage}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100 transition-colors text-sm font-medium"
                >
                  <MessageCircle className="w-5 h-5" />
                  Test Message Notification
                </button>
              </div>
            </div>

            {/* Upcoming Deadlines */}
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Deadlines</h2>
              <div className="space-y-4">
                <div className="py-2">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="font-medium text-sm text-gray-900">Grade Midterm Exams</h3>
                    <span className="px-2 py-0.5 text-xs font-medium rounded bg-red-100 text-red-700">
                      Due
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mb-1">Data Structures</p>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Calendar className="w-3 h-3" />
                    <span>Jan 15, 2026 | 5:00 PM</span>
                  </div>
                </div>
                <div className="border-b border-dashed border-gray-300"></div>
                <div className="py-2">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="font-medium text-sm text-gray-900">Submit Final Grades</h3>
                    <span className="px-2 py-0.5 text-xs font-medium rounded bg-gray-100 text-gray-700">
                      Upcoming
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mb-1">Web Development</p>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Calendar className="w-3 h-3" />
                    <span>Jan 20, 2026 | 11:59 PM</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <SearchPanel isOpen={showSearchPanel} onClose={() => setShowSearchPanel(false)} />
      <AddCourseModal
        isOpen={showAddCourseModal}
        onClose={() => setShowAddCourseModal(false)}
        onAddCourse={handleAddCourse}
      />
      {selectedCourse && (
        <CourseManagementModal
          isOpen={showCourseManagement}
          onClose={() => {
            setShowCourseManagement(false);
            setSelectedCourse(null);
          }}
          course={selectedCourse}
        />
      )}
      <MessagesInbox
        isOpen={showMessagesInbox}
        onClose={() => setShowMessagesInbox(false)}
        onSelectConversation={handleSelectConversation}
        onMarkAsRead={handleMarkAsRead}
      />
      {chatRecipient && (
        <ChatModal
          isOpen={showChatModal}
          onClose={() => {
            setShowChatModal(false);
            setChatRecipient(null);
          }}
          recipient={chatRecipient}
          onBack={handleBackToInbox}
        />
      )}
      {selectedCourse && (
        <EditCourseModal
          isOpen={showEditCourseModal}
          onClose={() => {
            setShowEditCourseModal(false);
            setSelectedCourse(null);
          }}
          course={selectedCourse}
          onUpdateCourse={handleUpdateCourse}
        />
      )}
    </div>
  );
}