import { useState } from "react";
import { Bell, X, UserPlus, Check, FileText } from "lucide-react";
import { useLocation } from "react-router-dom";

interface TeacherNotification {
  id: string;
  type: "enrollment";
  studentName: string;
  courseName: string;
  time: string;
  read: boolean;
}

interface StudentNotification {
  id: string;
  type: "material";
  courseName: string;
  materialName: string;
  time: string;
  read: boolean;
}

type Notification = TeacherNotification | StudentNotification;

export function NotificationDropdown() {
  const location = useLocation();
  const isStudentRoute = location.pathname.startsWith("/student");
  
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(
    isStudentRoute
      ? [
          {
            id: "1",
            type: "material",
            courseName: "Introduction to Computer Science",
            materialName: "Week 5 - Algorithm Analysis.pdf",
            time: "30 min ago",
            read: false,
          },
          {
            id: "2",
            type: "material",
            courseName: "Data Structures & Algorithms",
            materialName: "Assignment 3 - Binary Trees",
            time: "2 hours ago",
            read: false,
          },
          {
            id: "3",
            type: "material",
            courseName: "Web Development Fundamentals",
            materialName: "Lecture Video - React Hooks",
            time: "1 day ago",
            read: true,
          },
        ]
      : [
          {
            id: "1",
            type: "enrollment",
            studentName: "Emma Johnson",
            courseName: "Introduction to Computer Science",
            time: "2 min ago",
            read: false,
          },
          {
            id: "2",
            type: "enrollment",
            studentName: "Michael Chen",
            courseName: "Data Structures & Algorithms",
            time: "15 min ago",
            read: false,
          },
          {
            id: "3",
            type: "enrollment",
            studentName: "Sarah Williams",
            courseName: "Web Development Fundamentals",
            time: "1 hour ago",
            read: true,
          },
        ]
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="relative">
      {/* Bell Icon */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
      >
        <Bell className="w-6 h-6 text-gray-700" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          ></div>

          {/* Dropdown Panel */}
          <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-2xl border border-gray-200 z-50">
            {/* Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-gray-900">Notifications</h3>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Mark all read
                  </button>
                )}
              </div>
              {unreadCount > 0 && (
                <p className="text-sm text-gray-600">
                  You have {unreadCount} unread notification{unreadCount !== 1 ? "s" : ""}
                </p>
              )}
            </div>

            {/* Notifications List */}
            <div className="max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No notifications</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-gray-50 transition-colors ${
                        !notification.read ? "bg-blue-50" : ""
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            {notification.type === "enrollment" ? (
                              <UserPlus className="w-5 h-5 text-green-600" />
                            ) : (
                              <FileText className="w-5 h-5 text-green-600" />
                            )}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          {notification.type === "enrollment" ? (
                            <p className="text-sm text-gray-900">
                              <span className="font-semibold">
                                {notification.studentName}
                              </span>{" "}
                              enrolled in{" "}
                              <span className="font-semibold">
                                {notification.courseName}
                              </span>
                            </p>
                          ) : (
                            <p className="text-sm text-gray-900">
                              New material for{" "}
                              <span className="font-semibold">
                                {notification.courseName}
                              </span>
                              :{" "}
                              <span className="font-semibold">
                                {notification.materialName}
                              </span>
                            </p>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            {notification.time}
                          </p>
                        </div>
                        <div className="flex gap-1 flex-shrink-0">
                          {!notification.read && (
                            <button
                              onClick={() => markAsRead(notification.id)}
                              className="p-1 hover:bg-gray-200 rounded transition-colors"
                              title="Mark as read"
                            >
                              <Check className="w-4 h-4 text-gray-600" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {notifications.length > 0 && (
              <div className="p-3 border-t border-gray-200 text-center">
                <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                  View all notifications
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}