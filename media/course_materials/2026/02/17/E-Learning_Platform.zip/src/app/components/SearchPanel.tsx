import { useState } from "react";
import { Search, X, User, GraduationCap, Mail, MapPin, ArrowLeft, MessageCircle, Phone, Calendar, BookOpen, Award } from "lucide-react";
import { ChatModal } from "./ChatModal";

interface SearchPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

type ViewMode = "search" | "profile";

export function SearchPanel({ isOpen, onClose }: SearchPanelProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<"students" | "teachers">("students");
  const [viewMode, setViewMode] = useState<ViewMode>("search");
  const [selectedProfile, setSelectedProfile] = useState<any>(null);
  const [showChatModal, setShowChatModal] = useState(false);
  const [chatRecipient, setChatRecipient] = useState<any>(null);

  // Mock data
  const students = [
    {
      id: "1",
      name: "Emma Johnson",
      email: "emma.j@edu.com",
      location: "New York, USA",
      courses: 4,
      phone: "+1 (555) 123-4567",
      joinDate: "Sept 2025",
      bio: "Computer Science major passionate about AI and machine learning. Currently focusing on data structures and algorithms.",
      achievements: ["Dean's List Fall 2025", "First Place Hackathon 2025"],
    },
    {
      id: "2",
      name: "Michael Chen",
      email: "m.chen@edu.com",
      location: "Los Angeles, USA",
      courses: 3,
      phone: "+1 (555) 234-5678",
      joinDate: "Sept 2025",
      bio: "Aspiring software engineer interested in web development and cloud computing.",
      achievements: ["Best Project Award"],
    },
    {
      id: "3",
      name: "Sarah Williams",
      email: "s.williams@edu.com",
      location: "Chicago, USA",
      courses: 5,
      phone: "+1 (555) 345-6789",
      joinDate: "Jan 2025",
      bio: "Mathematics and Computer Science double major. Love solving complex problems.",
      achievements: ["Academic Excellence Award", "Math Olympiad Winner"],
    },
    {
      id: "4",
      name: "David Martinez",
      email: "d.martinez@edu.com",
      location: "Houston, USA",
      courses: 2,
      phone: "+1 (555) 456-7890",
      joinDate: "Sept 2025",
      bio: "New student exploring various fields in computer science.",
      achievements: [],
    },
  ];

  const teachers = [
    {
      id: "1",
      name: "Prof. Robert Smith",
      email: "r.smith@edu.com",
      department: "Computer Science",
      courses: 8,
      phone: "+1 (555) 111-2222",
      location: "Boston, USA",
      joinDate: "Jan 2020",
      bio: "Professor of Computer Science with 15 years of teaching experience. Specializing in algorithms and data structures.",
      achievements: ["Best Professor Award 2024", "Published 20+ Research Papers"],
    },
    {
      id: "2",
      name: "Dr. Lisa Anderson",
      email: "l.anderson@edu.com",
      department: "Mathematics",
      courses: 6,
      phone: "+1 (555) 222-3333",
      location: "Seattle, USA",
      joinDate: "Mar 2021",
      bio: "Mathematics educator passionate about making complex concepts accessible to students.",
      achievements: ["Excellence in Teaching Award 2023"],
    },
    {
      id: "3",
      name: "Prof. James Wilson",
      email: "j.wilson@edu.com",
      department: "Physics",
      courses: 5,
      phone: "+1 (555) 333-4444",
      location: "Denver, USA",
      joinDate: "Aug 2019",
      bio: "Physics professor with a focus on quantum mechanics and theoretical physics.",
      achievements: ["Research Grant Recipient 2024"],
    },
  ];

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredTeachers = teachers.filter(
    (teacher) =>
      teacher.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      teacher.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const results = searchType === "students" ? filteredStudents : filteredTeachers;

  const handleViewProfile = (person: any) => {
    setSelectedProfile({
      ...person,
      type: searchType === "students" ? "student" : "teacher",
    });
    setViewMode("profile");
  };

  const handleSendMessage = (profile: any) => {
    setChatRecipient({
      id: profile.id,
      name: profile.name,
      type: profile.type,
    });
    setShowChatModal(true);
  };

  const handleBackToSearch = () => {
    setViewMode("search");
    setSelectedProfile(null);
  };

  const handleClose = () => {
    onClose();
    // Reset state when closing
    setTimeout(() => {
      setViewMode("search");
      setSelectedProfile(null);
      setSearchQuery("");
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 z-40"
        onClick={handleClose}
      ></div>

      {/* Right Side Drawer */}
      <div className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col">
        {viewMode === "search" ? (
          <>
            {/* Search Header */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Search</h2>
                <button
                  onClick={handleClose}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {/* Search Type Toggle */}
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setSearchType("students")}
                  className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                    searchType === "students"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  <GraduationCap className="w-4 h-4 inline mr-2" />
                  Students
                </button>
                <button
                  onClick={() => setSearchType("teachers")}
                  className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                    searchType === "teachers"
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  <User className="w-4 h-4 inline mr-2" />
                  Teachers
                </button>
              </div>

              {/* Search Input */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder={`Search ${searchType}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  autoFocus
                />
              </div>
            </div>

            {/* Search Results */}
            <div className="flex-1 overflow-y-auto p-6">
              {results.length === 0 ? (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">
                    {searchQuery ? `No ${searchType} found` : `Search for ${searchType}`}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {searchType === "students"
                    ? filteredStudents.map((student) => (
                        <div
                          key={student.id}
                          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => handleViewProfile(student)}
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <GraduationCap className="w-5 h-5 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-gray-900">{student.name}</h3>
                              <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                                <Mail className="w-3 h-3 flex-shrink-0" />
                                <span className="truncate">{student.email}</span>
                              </div>
                              <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                                <span className="flex items-center gap-1">
                                  <MapPin className="w-3 h-3 flex-shrink-0" />
                                  {student.location}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    : filteredTeachers.map((teacher) => (
                        <div
                          key={teacher.id}
                          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => handleViewProfile(teacher)}
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <User className="w-5 h-5 text-green-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-gray-900">{teacher.name}</h3>
                              <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                                <Mail className="w-3 h-3 flex-shrink-0" />
                                <span className="truncate">{teacher.email}</span>
                              </div>
                              <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                                <span>{teacher.department}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            {/* Profile View */}
            {selectedProfile && (
              <>
                {/* Profile Header with Avatar Overlap */}
                <div className="relative">
                  {/* Gradient cover */}
                  <div className="h-40 bg-gradient-to-r from-blue-500 to-purple-600 relative">
                    <button
                      onClick={handleBackToSearch}
                      className="absolute top-4 left-4 p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors z-10"
                    >
                      <ArrowLeft className="w-5 h-5 text-white" />
                    </button>
                    <button
                      onClick={handleClose}
                      className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors z-10"
                    >
                      <X className="w-5 h-5 text-white" />
                    </button>
                  </div>
                  
                  {/* Avatar overlapping gradient and content - right aligned */}
                  <div className="absolute left-6 top-24 z-20">
                    <div className="w-32 h-32 bg-white rounded-full border-4 border-white shadow-xl flex items-center justify-center">
                      {selectedProfile.type === "student" ? (
                        <GraduationCap className="w-16 h-16 text-blue-600" />
                      ) : (
                        <BookOpen className="w-16 h-16 text-green-600" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Profile Content */}
                <div className="flex-1 overflow-y-auto">
                  <div className="px-6 pb-6">
                    {/* Name and Send Message */}
                    <div className="flex items-start justify-between gap-3 mb-6 pt-20">
                      <div className="flex-1">
                        <h2 className="text-2xl font-bold text-gray-900">{selectedProfile.name}</h2>
                        <p className="text-gray-600">
                          {selectedProfile.type === "student"
                            ? "Student"
                            : selectedProfile.department || "Teacher"}
                        </p>
                      </div>
                      <button
                        onClick={() => handleSendMessage(selectedProfile)}
                        className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors group relative flex-shrink-0"
                        title="Send Message"
                      >
                        <MessageCircle className="w-5 h-5" />
                        <span className="absolute right-full mr-2 top-1/2 -translate-y-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                          Send Message
                        </span>
                      </button>
                    </div>

                    {/* Bio */}
                    {selectedProfile.bio && (
                      <div className="mt-6">
                        <p className="text-gray-700 leading-relaxed">{selectedProfile.bio}</p>
                      </div>
                    )}

                    {/* Contact Information */}
                    <div className="bg-gray-50 rounded-lg p-4 mt-6">
                      <h3 className="font-semibold text-gray-900 mb-3">Contact Information</h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <Mail className="w-4 h-4 text-blue-600" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs text-gray-500">Email</p>
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {selectedProfile.email}
                            </p>
                          </div>
                        </div>
                        {selectedProfile.phone && (
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                              <Phone className="w-4 h-4 text-green-600" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Phone</p>
                              <p className="text-sm font-medium text-gray-900">
                                {selectedProfile.phone}
                              </p>
                            </div>
                          </div>
                        )}
                        {selectedProfile.location && (
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                              <MapPin className="w-4 h-4 text-purple-600" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Location</p>
                              <p className="text-sm font-medium text-gray-900">
                                {selectedProfile.location}
                              </p>
                            </div>
                          </div>
                        )}
                        {selectedProfile.joinDate && (
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                              <Calendar className="w-4 h-4 text-orange-600" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Member Since</p>
                              <p className="text-sm font-medium text-gray-900">
                                {selectedProfile.joinDate}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="bg-blue-50 rounded-lg p-4 text-center mt-6">
                      <BookOpen className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                      <p className="text-2xl font-bold text-gray-900">
                        {selectedProfile.courses || 0}
                      </p>
                      <p className="text-xs text-gray-600">
                        {selectedProfile.type === "student"
                          ? "Enrolled Courses"
                          : "Teaching Courses"}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>

      {/* Chat Modal */}
      {chatRecipient && (
        <ChatModal
          isOpen={showChatModal}
          onClose={() => {
            setShowChatModal(false);
            setChatRecipient(null);
          }}
          recipient={chatRecipient}
        />
      )}
    </>
  );
}