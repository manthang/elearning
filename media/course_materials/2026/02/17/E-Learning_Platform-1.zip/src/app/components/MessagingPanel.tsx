import { useState } from 'react';
import { Search, X, Send, User } from 'lucide-react';

type Person = {
  id: string;
  name: string;
  role: 'student' | 'teacher';
  email: string;
  avatar?: string;
  online?: boolean;
  course?: string;
};

interface MessagingPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MessagingPanel({ isOpen, onClose }: MessagingPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<{ text: string; from: 'me' | 'them'; time: string }[]>(
    []
  );

  // Mock data for students and teachers
  const people: Person[] = [
    {
      id: '1',
      name: 'Prof. Tanya Udland',
      role: 'teacher',
      email: 'tanya.udland@edulearn.com',
      online: true,
      course: 'Introduction to Computer Science',
    },
    {
      id: '2',
      name: 'Prof. Michael Chen',
      role: 'teacher',
      email: 'michael.chen@edulearn.com',
      online: false,
      course: 'Data Structures & Algorithms',
    },
    {
      id: '3',
      name: 'Prof. Lisa Anderson',
      role: 'teacher',
      email: 'lisa.anderson@edulearn.com',
      online: true,
      course: 'Web Development Fundamentals',
    },
    {
      id: '4',
      name: 'John Smith',
      role: 'student',
      email: 'john.smith@student.edulearn.com',
      online: true,
      course: 'Introduction to Computer Science',
    },
    {
      id: '5',
      name: 'Sarah Williams',
      role: 'student',
      email: 'sarah.williams@student.edulearn.com',
      online: false,
      course: 'Data Structures & Algorithms',
    },
    {
      id: '6',
      name: 'Michael Brown',
      role: 'student',
      email: 'michael.brown@student.edulearn.com',
      online: true,
      course: 'Web Development Fundamentals',
    },
  ];

  const filteredPeople = people.filter(
    (person) =>
      person.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.course?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSendMessage = () => {
    if (message.trim() && selectedPerson) {
      const newMessage = {
        text: message,
        from: 'me' as const,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages([...messages, newMessage]);
      setMessage('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-white border-l border-gray-200 shadow-xl z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">Messages</h2>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-100 rounded transition-colors"
        >
          <X className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Search */}
      <div className="p-4 border-b border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search students and teachers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Content Area */}
      {!selectedPerson ? (
        /* People List */
        <div className="flex-1 overflow-y-auto">
          {filteredPeople.length === 0 ? (
            <div className="p-4 text-center text-gray-500 text-sm">
              No people found matching your search.
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredPeople.map((person) => (
                <button
                  key={person.id}
                  onClick={() => setSelectedPerson(person)}
                  className="w-full p-4 hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <User className="w-5 h-5 text-blue-600" />
                      </div>
                      {person.online && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium text-sm text-gray-900 truncate">
                          {person.name}
                        </h3>
                        <span
                          className={`text-xs px-2 py-0.5 rounded ${
                            person.role === 'teacher'
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {person.role === 'teacher' ? 'Teacher' : 'Student'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 truncate">{person.email}</p>
                      {person.course && (
                        <p className="text-xs text-gray-400 mt-1 truncate">{person.course}</p>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Chat View */
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b border-gray-200">
            <button
              onClick={() => setSelectedPerson(null)}
              className="flex items-center gap-3 w-full text-left hover:bg-gray-50 p-2 -m-2 rounded transition-colors"
            >
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <User className="w-5 h-5 text-blue-600" />
                </div>
                {selectedPerson.online && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm text-gray-900 truncate">
                  {selectedPerson.name}
                </h3>
                <p className="text-xs text-gray-500">{selectedPerson.role}</p>
              </div>
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="text-center py-8">
                <User className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500">
                  No messages yet. Start a conversation with {selectedPerson.name}
                </p>
              </div>
            ) : (
              messages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex ${msg.from === 'me' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[75%] rounded-lg px-4 py-2 ${
                      msg.from === 'me'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{msg.text}</p>
                    <p
                      className={`text-xs mt-1 ${
                        msg.from === 'me' ? 'text-blue-100' : 'text-gray-500'
                      }`}
                    >
                      {msg.time}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 px-4 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
