import { BookmarkPlus, Play, MessageSquare } from 'lucide-react';
import { Course } from './CoursesView';
import { useState } from 'react';

interface CourseCardProps {
  course: Course;
  onLeaveFeedback: (courseId: string) => void;
  onStartCourse: (courseId: string) => void;
  onEnroll: (courseId: string) => void;
}

export function CourseCard({ course, onLeaveFeedback, onStartCourse, onEnroll }: CourseCardProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="border border-gray-200 rounded-lg p-4 bg-white hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 mb-1">{course.title}</h3>
          <p className="text-sm text-gray-600">{course.instructor}</p>
        </div>
        <span
          className={`px-2 py-1 text-xs font-medium rounded ${
            course.status === 'ACTIVE'
              ? 'bg-green-100 text-green-700'
              : 'bg-gray-100 text-gray-700'
          }`}
        >
          {course.status === 'ACTIVE' ? 'Active' : 'Not Enrolled'}
        </span>
      </div>

      {/* Progress Bar */}
      {course.isEnrolled && (
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-gray-600">Progress</span>
            <span className="text-xs font-medium text-gray-900">{course.progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{ width: `${course.progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2">
        {course.isEnrolled ? (
          <>
            <button
              onClick={() => onStartCourse(course.id)}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
            >
              <Play className="w-4 h-4" />
              {course.progress > 0 ? 'Continue' : 'Start Course'}
            </button>
            <div className="relative">
              <button
                onClick={() => onLeaveFeedback(course.id)}
                onMouseEnter={() => setShowTooltip(true)}
                onMouseLeave={() => setShowTooltip(false)}
                className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                title="Leave Feedback"
              >
                <MessageSquare className="w-5 h-5 text-gray-600" />
              </button>
              {showTooltip && (
                <div className="absolute top-full mt-1 right-0 bg-gray-900 text-white text-xs py-1 px-2 rounded whitespace-nowrap z-10">
                  Leave Feedback
                </div>
              )}
            </div>
          </>
        ) : (
          <button
            onClick={() => onEnroll(course.id)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-white border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors text-sm font-medium"
          >
            <BookmarkPlus className="w-4 h-4" />
            Enroll
          </button>
        )}
      </div>
    </div>
  );
}
