import { useState } from 'react';
import { MapPin, Calendar, Award, Edit2 } from 'lucide-react';
import exampleImage from 'figma:asset/616a7ae2745da9b9ea06fd10c7196c9a1c0e5066.png';

interface StudentProfileProps {
  onEditProfile: () => void;
}

export function StudentProfile({ onEditProfile }: StudentProfileProps) {
  const [isOnline, setIsOnline] = useState(true);

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-start gap-4">
          <div className="relative">
            <img
              src={exampleImage}
              alt="Emma Johnson"
              className="w-16 h-16 rounded-full object-cover"
            />
            <div
              className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white ${
                isOnline ? 'bg-green-500' : 'bg-gray-400'
              }`}
              title={isOnline ? 'Online' : 'Offline'}
            />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Emma Johnson</h2>
            <p className="text-sm text-gray-600 mb-3">Student</p>
            <div className="flex flex-col gap-1.5 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>New York, USA</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Joined September 2025</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4" />
                <span>4 Enrolled Courses</span>
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={onEditProfile}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Edit2 className="w-4 h-4" />
          Edit
        </button>
      </div>

      {/* Status Selector */}
      <div className="border-t border-gray-200 pt-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Status
        </label>
        <div className="flex gap-2">
          <button
            onClick={() => setIsOnline(true)}
            className={`px-4 py-2 text-sm rounded-lg font-medium transition-colors ${
              isOnline
                ? 'bg-green-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Online
          </button>
          <button
            onClick={() => setIsOnline(false)}
            className={`px-4 py-2 text-sm rounded-lg font-medium transition-colors ${
              !isOnline
                ? 'bg-gray-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Studying
          </button>
        </div>
      </div>
    </div>
  );
}
