import { useState } from "react";
import {
  GraduationCap,
  BookOpen,
  MessageCircle,
  LogOut,
} from "lucide-react";
import { StudentProfile } from "./components/StudentProfile";
import { CoursesView } from "./components/CoursesView";
import { MessagingPanel } from "./components/MessagingPanel";
import { UpcomingDeadlines } from "./components/UpcomingDeadlines";

export default function App() {
  const [isMessagingOpen, setIsMessagingOpen] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);

  const handleLeaveFeedback = (courseId: string) => {
    console.log("Leave feedback for course:", courseId);
    // Implement feedback modal/form here
  };

  const handleStartCourse = (courseId: string) => {
    console.log("Start/Continue course:", courseId);
    // Navigate to course content
  };

  const handleEnroll = (courseId: string) => {
    console.log("Enroll in course:", courseId);
    // Implement enrollment logic
  };

  const handleEditProfile = () => {
    setShowEditProfile(true);
    console.log("Edit profile");
    // Implement edit profile modal/form here
  };

  const handleLogout = () => {
    console.log("Logout");
    // Implement logout logic
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">
                EduLearn
              </h1>
            </div>
            <nav className="flex items-center gap-6">
              <button className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-blue-600 transition-colors">
                <BookOpen className="w-5 h-5" />
                <span className="font-medium">My Courses</span>
              </button>
              <button
                onClick={() =>
                  setIsMessagingOpen(!isMessagingOpen)
                }
                className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-blue-600 transition-colors relative"
              >
                <MessageCircle className="w-5 h-5" />
                <span className="font-medium">Messages</span>
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-red-600 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Logout</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile and Deadlines */}
          <div className="lg:col-span-1 space-y-6">
            <StudentProfile onEditProfile={handleEditProfile} />
            <UpcomingDeadlines />
          </div>

          {/* Right Column - Courses */}
          <div className="lg:col-span-2">
            <CoursesView
              onLeaveFeedback={handleLeaveFeedback}
              onStartCourse={handleStartCourse}
              onEnroll={handleEnroll}
            />
          </div>
        </div>
      </main>

      {/* Messaging Panel */}
      <MessagingPanel
        isOpen={isMessagingOpen}
        onClose={() => setIsMessagingOpen(false)}
      />
    </div>
  );
}