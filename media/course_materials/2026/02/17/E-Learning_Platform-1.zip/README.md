
  # E-Learning Platform

  This is a code bundle for E-Learning Platform. The original project is available at https://www.figma.com/design/o393Ya8PylMgcKKcyG4AQe/E-Learning-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  